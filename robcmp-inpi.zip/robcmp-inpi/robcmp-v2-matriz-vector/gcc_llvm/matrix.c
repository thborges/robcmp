
int main ()
{
	int a[3][2];

	a[2][1] = 2;

}

