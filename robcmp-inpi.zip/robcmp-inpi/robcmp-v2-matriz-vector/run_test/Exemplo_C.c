#include <stdio.h>

int main(){
	int a[150], i;
	for (i = 0; i < 150; i++){
		a[i] = 0;
	}
}
