#ifndef __SEMANTIC_H__
#define __SEMANTIC_H__

class Semantic{
	public:
		static Value *Verification();
};

#endif
