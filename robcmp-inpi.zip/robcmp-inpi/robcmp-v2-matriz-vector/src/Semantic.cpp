#include "Header.h"
	
Value *Semantic::Verification(){
}
