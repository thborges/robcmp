
#ifndef PINS_H
#define PINS_H

#ifdef __AVR_ATmega32U4__
#include "pins_atmega32u4.h"
#else
#include "pins_default.h"
#endif

#endif

