#include <stdio.h>

int func_name (int a, int b, int c){
	return (a * b) + c;
}

void main (){
	int c1 = 1, c2 = 0, int x;
	int z = c1 + c2;

	printf ("%d", z);

	for (i = 1; i <= c1; i++){
		x = c1 + i;
	}
}
