---
# Feel free to add content and custom Front Matter to this file.
# To modify the layout, see https://jekyllrb.com/docs/themes/#overriding-theme-defaults

layout: home
---

Documentação dos projetos desenvolvidos na disciplina Compiladores, na Universidade Federal de Jataí [UFG - Regional Jataí](https://computacao.jatai.ufg.br). Através do código do projeto no [github](https://github.com/thborges/robcmp), os alunos desenvolvem um frontend de linguagem de programação, empregando ferramentas como flex e yacc. O projeto tem o propósito de executar os programas num processador AVR (placa Arduino) integrando o frontend com o backend para AVR da suíte LLVM.

