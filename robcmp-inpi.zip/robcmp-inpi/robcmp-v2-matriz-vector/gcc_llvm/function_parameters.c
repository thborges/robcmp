int func(int var){
	return var;
}

int main(){
	int var = 2;
	func(var);
}
